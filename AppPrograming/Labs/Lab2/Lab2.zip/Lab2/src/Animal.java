/**
 * @author Abit Gurung (jkd175)
 * This class collects the animals names and types
 */
public class Animal {

   private String zonename;
   private String name;
   private String type;
   private boolean isCarnivore;
   public String carniore;

   Animal(String name, String type, String isCarnivore, String zonecode) {
      boolean carnivore;
      carnivore = isCarnivore.equals("TRUE");
      this.name = name;
      this.type = type;
      this.isCarnivore = carnivore;
      this.zonename = zonecode;
      this.carniore = isCarnivore;

   }
   public String getName() {
      return name;
   }
   public String getZonecode(){
      return zonename;
   }
   public String getCarniore()
   {
      return carniore;
   }
   public String getType() {
      return type;
   }
   public boolean isCarnivore() {
      return isCarnivore;
   }

   public String toString() {
      return " >>  " + getName() + " - " + getType() + (isCarnivore() ? " (Carnivore)" : " (Vegetarian)");
   }
}
