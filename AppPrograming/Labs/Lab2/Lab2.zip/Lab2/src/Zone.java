import java.util.ArrayList;

/**
 * @author Abit Gurung (jkd175)
 * THis class adds animals to respective zones
 */
public class Zone {

	private String name;
	private String risk;
	private String zone;
	ArrayList<Animal> animals = new ArrayList<>();

	Zone(String name, String risk, String zone) {
		this.name = name;
		this.risk = risk;
		this.zone = zone;
	}
	void addAnimal(Animal animal)
	{
		animals.add(animal);
	}
	public ArrayList<Animal> getAnimals()
	{
		return animals;
	}
	public void setZone(String zone)
	{
		this.zone = zone;
	}
	public String getZone()
	{
		return zone;
	}
	public String getName()
	{
		return name;
	}
	public String toString()
	{
		StringBuilder data = new StringBuilder("\n" + zone + ": " + getName()  + " Zone " + "(" +risk+" risk" +")");
		data.append("\n").append("-".repeat(Math.max(0, data.length()-1)));
		for(int j = 0; j < animals.size(); j++)
		{
			data.append("\n").append(animals.get(j));
		}
		return data.toString();
	}
}
