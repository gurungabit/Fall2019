import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
/**
 * @author Abit Gurung (jkd175)
 *
 */
public class Zoo {

   private String name;
   private ArrayList<Zone> _zone = new ArrayList<>();
   private int zoneCnt;

   Zoo(String name) {
      this.name = name;
      zoneCnt = 0;
   }
   void loadZones(String zonefile) {
      File file = new File(zonefile);
      try {
         Scanner inputStream = new Scanner(file);
         while(inputStream.hasNext()){
            String data = inputStream.next();
            String[] temp = data.split(",");
            String name = temp[0];
            String risk = temp[1];
            String zone = temp[2];
            Zone zones = new Zone(name, risk, zone);
            _zone.add(zones);
            addZone(_zone);
         }
         inputStream.close();
      } catch (FileNotFoundException e) {
         e.printStackTrace();
      }
   }
   void loadAnimals(String animalfile) {
      File file = new File(animalfile);
      try {
         Scanner inputStream = new Scanner(file);
         while(inputStream.hasNext())
         {
            inputStream.useDelimiter("\n");
            String data = inputStream.next();
            String[] temp = data.split(",");
            String name = temp[0];
            String type = temp[1];
            String isCarnivore = temp[2];
            String zonecode = temp[3];
            Animal animal = new Animal(name, type, isCarnivore, zonecode);
            for( int i = 0; i < _zone.size(); i++)
            {
               char temp1 = temp[3].charAt(0);
               char temp2 = _zone.get(i).getZone().charAt(0);
               if(temp1 == temp2)
               {
                  _zone.get(i).animals.add(animal);
               }
            }
         }
         inputStream.close();
      } catch (FileNotFoundException e) {
         e.printStackTrace();
      }

   }

   void relocate(String Name, String Zone) {
      Animal animal = new Animal("", "", "", "");
      for(int j = 0; j < _zone.size(); j++)
      {
         for(int k = 0; k < _zone.get(j).animals.size(); k++)
         {
            if(_zone.get(j).animals.get(k).getName().equals(Name))
            {
                String name = _zone.get(j).animals.get(k).getName();
                //System.out.println("Name = " + name);
                String type = _zone.get(j).animals.get(k).getType();
                //System.out.println("Name = " + type);
                String isCarnivore = _zone.get(j).animals.get(k).getCarniore();
                //System.out.println("Name = " + isCarnivore);
               animal = new Animal(name, type, isCarnivore, Zone);
               _zone.get(j).animals.remove(k);
               //System.out.println("Animal = " + animal);
               break;
            }
         }
         //System.out.println("Animal Outside = " + animal);
         char temp1 = Zone.charAt(0);
         char temp2 = _zone.get(j).getZone().charAt(0);
         if(temp1 == temp2)
         {
            _zone.get(j).animals.add(animal);
            break;
         }
      }
   }
   void save() {
      try {
         FileWriter fw = new FileWriter("animalData/animals.csv");
         for(int j = 0; j < _zone.size(); j++) {
            for (int k = 0; k < _zone.get(j).animals.size(); k++) {
               String name = _zone.get(j).animals.get(k).getName();
               String type= _zone.get(j).animals.get(k).getType();
               String isCarnivore = _zone.get(j).animals.get(k).getCarniore();
               String zone = _zone.get(j).animals.get(k).getZonecode();
               //System.out.println("Name = " + name + " Type = " + type + " isCarnivore = " + isCarnivore + " Zone = " + zone);
               fw.append(name);
               fw.append(",");
               fw.append(type);
               fw.append(",");
               fw.append(isCarnivore);
               fw.append(",");
               fw.append(zone);
               fw.append("\n");
            }
         }
         fw.flush();
         fw.close();
      } catch (IOException e) {
         e.printStackTrace();
      }
   }
   private void addZone(ArrayList<Zone> zones) {
      if (zoneCnt < zones.size()) {
         zoneCnt++;
      }
   }
   // getter for the zoo names
   public String getName() {
      return name;
   }

   // count number of zones
   public int getZoneCnt() {
      return zoneCnt;
   }

   // setter for zone
   public void setZones(ArrayList<Zone> zones) {
      this._zone = zones;
   }
   public String toString() {
      StringBuilder data = new StringBuilder("\n\n" + "Welcome to " + "\"" + name + "\"" + "!\n");

      data.append("=".repeat(Math.max(0, data.length() - 1)));
      for(int j = 0; j < getZoneCnt(); j++)
      {
         data.append("\n").append(_zone.get(j));
      }
      return data.toString();
   }
}
