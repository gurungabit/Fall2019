#!/bin/bash
echo "Total Course records: " $(ls -l ./data/*.crs | wc -l)